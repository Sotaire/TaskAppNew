package com.example.taskapp.ui.interfaces;

public interface OnViewListener {
    void onViewPagerClickListener ();
}
