package com.example.taskapp.ui.interfaces;

public interface OnItemClickListener {
    void onItem(int position);

    void onItemLongClick(int position);
}
