package com.example.taskapp.ui.home;

import com.example.taskapp.TaskAdapter;

public interface AdapterListener {
    void delete(TaskAdapter taskAdapter);
}
